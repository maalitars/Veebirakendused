import org.junit.Test;
import org.openqa.selenium.*;

import static junit.framework.TestCase.assertEquals;

public class BasicTest extends TestHelper {

    private String email = "addtestemailhere";
    private String password = "addtestpasswordhere";


    @Test
    public void loginLogoutTest(){

        login(email, password);
        //kontrollib, et sai edukalt sisse logitud
        assertEquals("Populaarseimad filmid praegu:", driver.findElement(By.xpath("//div[@id='movies']/h1")).getText());

        logout();

        //kontrollib, et logis välja ja jõudis tagasi avalehele
        assertEquals("POLE KASUTAJAT? REGISTREERU",driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/p")).getText());
    }

    @Test
    public void loginFalsePassword() {
        login(email, "triinulepa");
        //kontrollib, et sai edukalt sisse logitud
        assertEquals("Vale parool, proovi uuesti!", driver.findElement(By.xpath("//h2")).getText());
    }

    @Test
    public void registerAndDeleteAccount(){
        register("Mees","Metsast","meesmetsast@gmail.com","meesmetsast");
        //kontrollib, kas kasutaja sai registreeritud
        assertEquals("Tervitus sõnum on saadetud teie emailile: meesmetsast@gmail.com.", driver.findElement(By.xpath("//h2")).getText());
        deleteAccount();
        //kontrollib kas kasutaja sattus pärast kustutamist avalehele
        assertEquals("POLE KASUTAJAT? REGISTREERU",driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/p")).getText());
        login("meesmetsast@gmail.com","meesmetsast");
        assertEquals("Sellist kasutajat ei eksisteeri!", driver.findElement(By.xpath("//h2")).getText());

    }

    @Test
    public void registerWithExistingEmail(){
        register("Lepa","Triinu",email,"lepa");
        assertEquals("Selline kasutaja juba eksisteerib", driver.findElement(By.xpath("//h2")).getText());
    }

    @Test
    public void registerWithoutPassword(){
        register("Lepa","Triinu","lepatriinu+99@gmail.com","");
        assertEquals("REGISTREERU", driver.findElement(By.xpath("//p")).getText());
    }


    @Test
    public void searchForAMovie(){

        driver.get("http://46.101.6.112/pages/filmid.php");

        driver.findElement(By.xpath("//li[2]/a/div")).click();
        driver.findElement(By.id("searchText")).click();
        driver.findElement(By.id("searchText")).clear();
        driver.findElement(By.id("searchText")).sendKeys("avengers");
        driver.findElement(By.id("searchForm")).submit();

        System.out.println(driver.findElement(By.xpath("/html/body/div[1]/div[2]/h3[2]")).getText());

        boolean bool = driver.findElement(By.xpath("/html/body/div[1]/div[2]/h3[2]")).getText().contains("Avengers");

        assertEquals(true,bool);


    }

    @Test
    public void showingPopularMovies(){
        login(email, password);
        assertEquals("Populaarseimad filmid praegu:", driver.findElement(By.xpath("//div[@id='movies']/h1")).getText());

        boolean bool = driver.findElement(By.xpath("/html/body/div[1]")).getText().contains("20.");
        System.out.println(driver.findElement(By.xpath("/html/body/div[1]")).getText());
        assertEquals(true,bool);

        logout();
        assertEquals("POLE KASUTAJAT? REGISTREERU",driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/p")).getText());
    }

    @Test
    public void addAndRemoveProfilePicture(){
        login(email,password);
        driver.findElement(By.xpath("//li[3]/a/div")).click();
        WebElement el = driver.findElement(By.xpath("//*[@id=\"fileUpload\"]"));
        el.sendKeys("C:\\Users\\Maali\\Desktop\\aaaa.jpg"); //change the path according to your computer
        driver.findElement(By.xpath("/html/body/div[1]/div/form[1]/button")).click();

        WebElement element = driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/img"));
        boolean bool = element.getAttribute("alt").contains("uploads/aaaa.jpg");

        assertEquals(true, bool);

        driver.findElement(By.xpath("/html/body/div[1]/div/form[2]/button")).click();

        WebElement element2 = driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/img"));
        boolean bool2 = element2.getAttribute("src").contains("uploads/profilesdefault.jpg");

        assertEquals(true, bool2);

        logout();
    }


}
