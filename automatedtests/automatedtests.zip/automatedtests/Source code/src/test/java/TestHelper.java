import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

public class TestHelper {

    static WebDriver driver;
    final int waitForResposeTime = 4;
    String baseUrl = "http://46.101.6.112/";

    @Before
    public void setUp(){
        System.setProperty("webdriver.gecko.driver", "C:\\Users\\Maali\\Downloads\\geckodriver-v0.20.1-win64\\geckodriver.exe");
        driver = new FirefoxDriver();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get(baseUrl);

    }

    void goToPage(String page){
        WebElement elem = driver.findElement(By.linkText(page));
        elem.click();
        waitForElementById(page);
    }

    void waitForElementById(String id){
        new WebDriverWait(driver, waitForResposeTime).until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
    }

    public boolean isElementPresent(By by) {
        try {
            driver.findElement(by);
            return true;
        }
        catch (NoSuchElementException e) {
            return false;
        }
    }
    void login(String username, String email){
        //driver.get(baseUrl);
        //läheb login lehele
        driver.findElement(By.xpath("//p")).click();
        //sisestab meili ja parooli
        driver.findElement(By.id("email")).sendKeys(username);
        driver.findElement(By.id("password")).sendKeys(email);
        //logib sisse
        driver.findElement(By.name("login")).click();
    }

    void logout(){
        //klikkab välja logimisele
        WebElement logout =  driver.findElement(By.xpath("/html/body/header/div/nav/div/form/ul/li[5]/a/div"));
        logout.click();
    }

    void register(String firstname, String lastname,String email, String password){
        //läheb registreerimislehele
        driver.findElement(By.xpath("//div[@id='leftbutton']/div/p")).click();
        //täidab ära kõik lahtrid
        driver.findElement(By.id("firstname")).sendKeys(firstname);
        driver.findElement(By.id("lastname")).sendKeys(lastname);
        driver.findElement(By.id("email")).sendKeys(email);
        driver.findElement(By.id("password")).sendKeys(password);
        //üritab registreerida
        driver.findElement(By.name("register")).click();
    }

    void deleteAccount(){
        driver.findElement(By.id("centerbutton")).click();
        driver.findElement(By.xpath("//li[3]/a/div")).click();
        driver.findElement(By.xpath("(//button[@name='delete'])[2]")).click();
    }

    @After
    public void tearDown(){
        driver.close();
    }

}